<link rel="stylesheet" href="style.css">
<link rel="shortcut icon" type="image/png" href="img/ico2.png">
<script src="https://kit.fontawesome.com/f72e62bf58.js" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
