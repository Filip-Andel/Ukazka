<script src="https://cdn.tiny.cloud/1/ayqu27s0z85wck4is65ekpqjcopw2j6dv97euuaxvrhai9ev/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
     tinymce.init({
      selector: 'textarea',
      plugins: ' lists link autoresize fullscreen insertdatetime advlist image emoticons autolink lists media table',
      toolbar: '',
      toolbar_mode: 'floating',
      menubar: "",
      readonly : 1,
      spellchecker_language: "off",
      forced_root_block : 'div',
    });
</script>